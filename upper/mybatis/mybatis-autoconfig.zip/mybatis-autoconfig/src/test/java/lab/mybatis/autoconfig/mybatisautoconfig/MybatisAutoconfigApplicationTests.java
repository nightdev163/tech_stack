package lab.mybatis.autoconfig.mybatisautoconfig;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MybatisAutoconfigApplicationTests {

	@Test
	void contextLoads() {
	}

}
